import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

def show_pie_chart():
    # Data for the pie chart
    labels = ['Category 1', 'Category 2', 'Category 3', 'Category 4']
    sizes = [30, 25, 20, 25]  # These represent the percentages of each category

    # Create a Figure and Axes
    fig, ax = plt.subplots()

    # Plot the pie chart
    ax.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)

    # Set aspect ratio to be equal so that the pie is drawn as a circle
    ax.axis('equal')

    # Create a Tkinter canvas containing the pie chart
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.draw()

    # Display the canvas on the Tkinter window
    canvas.get_tk_widget().pack()
    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

# Create the Tkinter root window
root = tk.Tk()
root.title("Pie Chart Example")

# Create and display the pie chart
show_pie_chart()

# Start the Tkinter event loop
root.mainloop()
